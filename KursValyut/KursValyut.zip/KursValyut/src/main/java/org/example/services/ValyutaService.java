package org.example.services;

import org.example.models.Valyuta;

import java.util.List;

public interface ValyutaService {
    List<Valyuta> getValyuta();
}
